// Javascript Document

function expand_menu_f() {
	if (document.getElementById('expandable').style.display == 'none') {
		document.getElementById('expandable').style.display = 'block';
	} else {
		document.getElementById('expandable').style.display = 'none';
	}
}