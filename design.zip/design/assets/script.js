// JavaScript Document

/*var view_port = 3000 - screen.width;
function set_viewport() {
	alert(view_port);
	document.getElementsByClassName('carosel_elements').style.transform = 'translate(-' + view_port + ', 0)';
}
function move_left() {
	document.getElementById('carosel_control').style.transform = 'translate3d(-1870, 0, 0)';
}*/

$(document).ready(function(){
  $('.your-class').slick({
    setting-name: setting-value
  });
});